import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeLayoutComponent } from '../employee-layout/employee-layout.component';
import { UserService } from '../../../models/user.service';
import { User } from '../../../models/user.model';


@Component({
  selector: 'app-login-layout',
  templateUrl: './login-layout.component.html',
  styleUrl: './login-layout.component.css'
})
export class LoginLayoutComponent {

  showDashboard: boolean = false;
  userEmail: string = '';
  userPassword: string = '';

  constructor( private userService:UserService , private router: Router) {
   // this.login();
  }

  login() {
    console.log("hiiiii");
    this.userService.login(this.userEmail, this.userPassword).subscribe(
      (user :User) => {
        localStorage.setItem("user",JSON.stringify(user));
        localStorage.setItem("Email",JSON.stringify(user.userEmail));
        const designation = user.designation;
        console.log(designation);
        if (designation === 'Admin') {
          console.log("Navigated to admin page");
          this.router.navigate(['/admin']);
        }
        else if (designation === 'Manager') {
          console.log("Navigated to manager page");
          this.router.navigate(['/manager']);
        }
        else if (designation === 'PMO') {
          console.log("Navigated to pmo page");
          this.router.navigate(['/pmo']);
        }
        else {
          console.log("Navigated to employee page");
          this.router.navigate(['/employee']);
        }
      },
      (error) => {
        console.error('Login failed:', error);
        this.router.navigate(["/login"])
      }
    );

    }
}


