import { Routes } from '@angular/router';


export const AuthLayoutRoutes: Routes = [
]
