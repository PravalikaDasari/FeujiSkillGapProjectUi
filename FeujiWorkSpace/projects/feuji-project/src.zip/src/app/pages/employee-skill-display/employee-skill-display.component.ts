import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { EmployeeUiBean } from '../../../models/EmployeeSkill.model';
import { EmployeeSkillGet } from '../../../models/EmployeeSkillGet.model';
import { ConfirmDialogComponent } from '../skillgap/confirm-dialog/confirm-dialog.component';
import { EmployeeSkillService } from '../../services/employee-skill.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-employee-skill-display',
  templateUrl: './employee-skill-display.component.html',
  styleUrl: './employee-skill-display.component.css',
})

export class EmployeeSkillDisplayComponent implements OnInit {
  constructor(private http: HttpClient, private empskillService: EmployeeSkillService, private dialog: MatDialog) { }
  empMail: string = '';
  public employeeSkill: EmployeeUiBean = new EmployeeUiBean(this.empMail, "", '', '', '', '', '', '', '', '', '0')
  employeesSkillGet: EmployeeSkillGet[] = [];
  skillCategories: any[] = [];
  technicalcategories: any[] = [];
  skills: any[] = [];
  skillCatogoryInput:string='Skill Category'
  skillTypeInput='Skill Type';
  skillCompetencyInput="Skill Competency"
  skillTypes: any[] = [];   
  skillTypes1: any[] = [];   
  skillCompetencies:any[]=[];
  skillCompetencies1:any[]=[];
  editedRow: any;
  skillCategory: string = '';
  technicalCategory: string = '';
  showNewRow: boolean = false;
  newRows: any[] = [];
  isEditModee: boolean = false;
  editModes: boolean[] = [];
  editMode: boolean = false;
  skillNames: string[] = [];
  selectedSkillNames: string[] = [];

  newRow: any = {
    employeeMail: this.empMail,
    skillCategory: '',
    technicalCategory: '',
    skillId: '',
    skillTypeId: '',
    competencyLevelId: '',
    certification: '',
    description: '',
    comments: '',
    yearsOfExp: '',
    isDeleted: '0'
  };

  addNewRow() {
    this.newRows.push({
      employeeMail: this.empMail,
      skillCategory: '',
      technicalCategory: '',
      skillId: '',
      skillTypeId: '',
      competencyLevelId: '',
      certification: '',
      description: '',
      comments: '',
      yearsOfExp: '',
      isDeleted: 0
    });
  }


  isEditMode(index: number): boolean {

    return this.editModes[index];
  }

  onEditMode(index: number) {
     this.getSkillType(this.skillTypeInput)
    this.getSkillCompetency(this.skillCompetencyInput)
    this.editModes[index] = !this.editModes[index];
    this.editMode = !this.editMode;
    this.editedRow = this.employeesSkillGet[index]
    
  }

  ngOnInit() {
    const email = localStorage.getItem("Email");
    if (email) {
      this.empMail = JSON.parse(email);
    }
    this.getAllEmployeeSkills(this.empMail);
    this.empskillService.getSkillCategories(this.skillCatogoryInput).subscribe(
      (resp: string[]) => {
        this.skillCategories = resp as any[];
      },
      (error) => {
        Swal.fire({
          title: ' Failed to Fetch!',
          text: 'failed to fetch skill categories',
          icon: 'error',
          confirmButtonText: 'Ok',
        });
      }
    );
    this.getSkillType(this.skillTypeInput);
    this.getSkillCompetency(this.skillCompetencyInput)
  }

  getAllEmployeeSkills(empMail: string) {
    this.empskillService.getAllEmployeeSkills(empMail).subscribe(
      (resp: EmployeeSkillGet[]) => {
        this.employeesSkillGet = resp;
      },
      (error) => {
        Swal.fire({
          title: ' Failed to Fetch!',
          text: 'failed to fetch all employee skills',
          icon: 'error',
          confirmButtonText: 'Ok',
        });
      }
    );
  }
  isTechnicalCategoryDisabled: boolean = false;
  onSelectSkillCategory(event: any, index: number) {
    this.skillCategory = event.target.value
    this.empskillService.getTechnicalCategory(this.skillCategory).subscribe((resp: any) => {
      this.technicalcategories[index] = resp;
    },
      (error) => {
        Swal.fire({
          title: ' Failed to Fetch!',
          text: 'failed to fetch  technical categories',
          icon: 'error',
          confirmButtonText: 'Ok',
        });
      })
  }

  onSelectTechnicalCategory(event: any, index: number) {
    
    const selectedTechnicalCategory = event.target.value;
    this.empskillService
      .getSkills(selectedTechnicalCategory)
      .subscribe((res:any[]) => {
        this.skills[index] = res.filter(skill => {
          return !this.employeesSkillGet.some(employeeSkill => employeeSkill.skillId === skill.skillName) && !this.skillNames.includes(skill.skillName);
        });

      },
        (error) => {
          Swal.fire({
            title: ' Failed to Fetch!',
            text: 'failed to fetch skills',
            icon: 'error',
            confirmButtonText: 'Ok',
          });
        });
  }

  isTechnicalCategoryDisabledm(i: number) {
    this.isTechnicalCategoryDisabled = this.skills[i].length === 0;
  }

  onSelectSkillName(event: any, i: number) {
    const selectedSkillId = event.target.value;
    let skill = (this.skills[i].find((skill: any) => skill.skillId === Number(selectedSkillId)));
    this.skillNames.push(skill.skillName)
  }

  getSkillType(skillType: string) {

    this.empskillService
      .getSkilltype(skillType)
      .subscribe((res: any[]) => {        
        this.skillTypes = res ;
        this.skillTypes1 = res ;
      },
        (error) => {
          Swal.fire({
            title: ' Failed to Fetch!',
            text: 'failed to fetch  skillstype',
            icon: 'error',
            confirmButtonText: 'Ok',
          });
        });

  }

  getSkillCompetency(skillCategory: string) {
    this.empskillService
      .getSkillCompetency(skillCategory)
      .subscribe((res:any[]) => {
        this.skillCompetencies = res;
        this.skillCompetencies1 = res;
      },
        (error) => {
          Swal.fire({
            title: ' Failed to Fetch!',
            text: 'failed to fetch skills competency',
            icon: 'error',
            confirmButtonText: 'Ok',
          });
        });
  }

  fetchValuesEdit(skillType: string, SkillCompetency: string, SkillCertification: string) {
    this.empskillService.getSkilltype(skillType).subscribe((res) => {
      this.skillTypes = res;

    },
      (error) => {
        Swal.fire({
          title: ' Failed to Fetch!',
          text: 'failed to fetch skills type',
          icon: 'error',
          confirmButtonText: 'Ok',
        });
      })

    this.empskillService.getSkillCompetency(SkillCompetency).subscribe((res) => {
      this.skillCompetencies = res;
    },
      (error) => {
        Swal.fire({
          title: ' Failed to Fetch!',
          text: 'failed to fetch skillCompetencies',
          icon: 'error',
          confirmButtonText: 'Ok',
        });
      })
  }

  editedSkillType(event: any, index: number) {
    this.editedRow.skillTypeId = event.target.value
  }

  editedCompetency(event: any, index: number) {
    this.editedRow.competencyLevelId = event.target.value
  }

  editedCertifcation(event: any, index: number) {
    this.editedRow.certification = event.target.value
  }

  editedDescription(event: any, index: number) {
    this.editedRow.description = event.target.value
  }

  editedComments(event: any, index: number) {
    this.editedRow.comments = event.target.value
  }

  editedYearOfExp(event: any, index: number) {
    this.editedRow.yearsOfExp = event.target.value
  }

  onEditModeToggle() {
    if (this.isEditModee) {
      this.saveRowChanges();
    } else {
      this.isEditModee = !this.isEditModee;
      this.editModes.fill(this.isEditModee);
      this.editedRow = { ...this.employeeSkill };
    }
  }


  saveRowChanges() {

    this.empskillService.editEmployeeSkill(this.editedRow, this.editedRow.employeeSkillId).subscribe(
      (resp) => {
        this.editMode = false;
      },
      (error) => {
        Swal.fire({
          title: ' Edit failed!',
          text: 'failed to edit skill details',
          icon: 'error',
          confirmButtonText: 'Ok',
        });
      }
    );
  }

  onRemove(index: number) {
    this.empskillService.deleteRow(this.employeesSkillGet[index].employeeSkillId).subscribe((res) => {
      const response = res;
    })
    this.employeesSkillGet.splice(index, 1);
    this.editModes.splice(index, 1);
  }

  openConfirmationDialogAdded(index: number) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: { title: 'Confirm Deletion', message: 'Are you sure you want to delete the record?' }
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.newRows.splice(index, 1);
      }
    });
  }

  openConfirmationDialog(index: number) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: { title: 'Confirm Deletion', message: 'Are you sure you want to delete the record?' }
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.onRemove(index);
      }
    });
  }

  saveExtraAddedRows(employeeAddedSkill: EmployeeUiBean[]) {
    this.empskillService.postEmployeeSkills(employeeAddedSkill).subscribe(
      (res: EmployeeUiBean[]) => {
        Swal.fire({
          title: 'Saved Sucessfully',
          text: 'skill added',
          icon: 'success',
          confirmButtonText: 'Ok',
        });
        this.getAllEmployeeSkills(this.empMail)
      },
      (error) => {
        Swal.fire({
          title: 'Failed to Save!',
          text: 'failed to save skill details',
          icon: 'error',
          confirmButtonText: 'Ok',
        });
      }
    );

    this.newRows = [];
  }

  refreshPage() {
    window.location.reload();
  }

}
