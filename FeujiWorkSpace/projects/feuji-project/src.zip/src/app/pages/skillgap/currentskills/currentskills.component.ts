import { Component } from '@angular/core';
import { SkillService } from '../../../../models/skill.service';

@Component({
  selector: 'app-currentskills',
  templateUrl: './currentskills.component.html',
  styleUrl: './currentskills.component.css'
})
export class CurrentskillsComponent {
  
}
