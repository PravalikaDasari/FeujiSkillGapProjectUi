export class SkillNamesDto{
    constructor(
        public skillName:string,
        public skillType:string,
        public skillTypeId:number
    ){ }
}