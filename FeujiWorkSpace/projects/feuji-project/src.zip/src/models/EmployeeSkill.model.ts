export class EmployeeUiBean{
    constructor(   
    public  employeeMail:string,
    public  skillCategory:string,
	public  TechnicalCategory:string,
	public  skillId:string,
	public  skillTypeId:string,
	public  competencyLevelId:string,
	public  yearsOfExp:string,
	public  certification:string,
	public  description:string,
	public  comments:string,	
	public  isDeleted:string,
    ){}
  }