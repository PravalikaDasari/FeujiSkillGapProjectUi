export class SkillCompetency{
    constructor(
        public roleId:number,
        public roleName:string,
        public skillId:number,
        public skillTypeId:number,
	    public  competencyLevelId:number
    ){}
}