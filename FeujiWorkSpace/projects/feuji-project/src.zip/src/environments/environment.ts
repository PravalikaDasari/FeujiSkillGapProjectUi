
export const environment = {
  production: false,
  SkillSetUrl: 'http://localhost:8090/api', 
  EmployeeSkillUrl:'http://localhost:8086/api',
  ReferenceServiceUrl:'http://localhost:8081/api',
  SkillService:'http://localhost:8087/api'
};
